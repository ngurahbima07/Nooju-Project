import React, { useState, useRef, useEffect } from 'react';
import '@fullcalendar/react/dist/vdom';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
import HotelIcon from '@mui/icons-material/Hotel';
import BedIcon from '@mui/icons-material/Bed';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import AddIcon from '@mui/icons-material/Add';
import LockIcon from '@mui/icons-material/Lock';
import LockOpenIcon from '@mui/icons-material/LockOpen';
import { Snackbar, Alert, withTheme } from '@mui/material';
import MainCard from 'components/MainCard';
import { useTheme } from '@mui/material';
import axios from 'axios';
import BuildIcon from '@mui/icons-material/Build';
import {
  Modal,
  Box,
  Typography,
  Button,
  Stack,
  TextField,
  IconButton,
  MenuItem,
  Grid,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Paper,
} from '@mui/material';
import {
  Delete as DeleteIcon,
  Edit as EditIcon,
  Close as CloseIcon,
  Save as SaveIcon
} from '@mui/icons-material';

export default function BookingChart() {
  const [events, setEvents] = useState([]);
  const [newEvent, setNewEvent] = useState({
    open: false,
    firstName: '',
    lastName: '',
    email: '',
    roomType: '',
    subRoom: '',
    ratePlan: '',
    adult: '',
    children: '',
    checkin: '',
    checkout: '',
    totalPrice: 0,
  });

useEffect(() => {
  axios.get('http://localhost:8002/api/reservations')
    .then((res) => {
      const formatted = res.data.map((item) => ({
        id: item.id, // ✅ ID dari database
        title: `${item.first_name} ${item.last_name} - ${item.room_type} - ${item.sub_room}`,
        start: item.check_in_date,
        end: item.check_out_date,
        backgroundColor: '#3788d8',
        extendedProps: item
      }));
      setEvents(formatted);
    });
}, []);

  

  const theme = useTheme();


  const [filterDate, setFilterDate] = useState(new Date().toISOString().split('T')[0]);
  const [maintenanceModal, setMaintenanceModal] = useState(false);
  const [maintenanceEvent, setMaintenanceEvent] = useState({
    roomType: '',
    room: '',
    reason: '',
    start: '',
    end: '',
  });

//deklarasi room
const rooms = [
    ...Array.from({ length: 4 }, (_, i) => ({ roomType: 'Standard', subRoom: `${i + 1}` })),
    ...Array.from({ length: 8 }, (_, i) => ({ roomType: 'Superior', subRoom: `${i + 5}` })),
  ];

  useEffect(() => {
  axios.get('http://localhost:8002/api/reservations')
    .then((res) => {
      const formatted = res.data.map((item) => ({
        id: item.id,
        title: `${item.first_name} ${item.last_name} - ${item.room_type} - ${item.sub_room}`,
        start: item.check_in_date,
        end: item.check_out_date,
        backgroundColor: '#3788d8',
        extendedProps: {
          ...item
        }
      }));
      setEvents(formatted);
    })
    .catch((err) => {
      showSnackbar("Gagal memuat data dari backend ❌", "error");
      console.error(err);
    });
}, []);



  //kunci
  const [lockDrag, setLockDrag] = useState(false);


  //pengecekan kamar
  const isRoomExist = (roomType, subRoom) => {
    return rooms.some(room => room.roomType === roomType && room.subRoom === subRoom);
  };

  //rubah alert jadi mui
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success', // bisa 'success', 'error', 'info', atau 'warning'
  });

  const showSnackbar = (message, severity = 'success') => {
    setSnackbar({ open: true, message, severity });
  };
  
  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };
  
  

  // Fungsi validasi ketersediaan kamar
// Fungsi validasi ketersediaan kamar (dengan pengecualian eventId)
const checkRoomAvailability = (subRoom, checkin, checkout, eventId = null) => {
  const newCheckin = new Date(checkin);
  const newCheckout = new Date(checkout);

  return !events.some((event) => {
    if (event.extendedProps.subRoom !== subRoom) return false;

    // 🚩 abaikan event itu sendiri saat validasi
    if (eventId && event.id === eventId) return false;

    const eventStart = new Date(event.start);
    const eventEnd = new Date(event.end);

    return (
      (newCheckin >= eventStart && newCheckin < eventEnd) ||
      (newCheckout > eventStart && newCheckout <= eventEnd) ||
      (newCheckin <= eventStart && newCheckout >= eventEnd)
    );
  });
};


  
  

const [editMode, setEditMode] = useState(false);
const [deleteConfirm, setDeleteConfirm] = useState(false);

  const [selectedEvent, setSelectedEvent] = useState(null);
  const calendarRef = useRef(null);

  useEffect(() => {
    if (calendarRef.current) {
      calendarRef.current.getApi().refetchEvents();
    }
  }, [events]);

  const handleDateClick = (arg) => {
    setNewEvent({
      open: true,
      firstName: '',
      lastName: '',
      email: '',
      roomType: '',
      subRoom: '',
      ratePlan: '',
      adult: '',
      children: '',
      checkin: arg.dateStr,
      checkout: arg.dateStr,
    });
  };

  const handleUpdateEvent = () => {
    // 🚀 PERUBAHAN: Validasi field wajib
    if (!selectedEvent.firstName || !selectedEvent.lastName || !selectedEvent.roomType) {
      showSnackbar("Nama depan, nama belakang, dan tipe kamar wajib diisi!");
      return;
    }
  
    // 🚀 PERUBAHAN: Update events di state
    setEvents(prevEvents => 
      prevEvents.map(event => 
        event.id === selectedEvent.id 
          ? { 
              ...event,
              title: `${selectedEvent.firstName} ${selectedEvent.lastName} - ${selectedEvent.roomType} - ${selectedEvent.subRoom}`,
              start: selectedEvent.checkin,
              end: selectedEvent.checkout,
              extendedProps: { ...selectedEvent }
            } 
          : event
      )
    );
    
    setEditMode(false); // 🚀 PERUBAHAN: Matikan edit mode
    showSnackbar("Data berhasil diperbarui!");
  };
  
  const handleDeleteEvent = () => {
    if (!selectedEvent?.id) {
      showSnackbar("Event tidak valid", "error");
      return;
    }
  
    axios.delete(`http://localhost:8002/api/reservations/${selectedEvent.id}`)
      .then(() => {
        // ✅ Langsung hapus dari state React
        setEvents((prev) => prev.filter(event => event.id !== selectedEvent.id));
        showSnackbar("Reservasi berhasil dihapus!");
        setSelectedEvent(null);
        setDeleteConfirm(false);
      })
      .catch((err) => {
        showSnackbar("Gagal hapus dari backend", "error");
        console.error(err);
      });
  };
  
  
  

  const handleAddEvent = () => {
    if (
      !newEvent.firstName ||
      !newEvent.lastName ||
      !newEvent.roomType ||
      !newEvent.subRoom ||
      !newEvent.checkin ||
      !newEvent.checkout
    ) {
      showSnackbar("Mohon isi semua field yang diperlukan.");
      return;
    }
  
    if (!checkRoomAvailability(newEvent.subRoom, newEvent.checkin, newEvent.checkout)) {
      showSnackbar(`Kamar nomor ${newEvent.subRoom} tidak tersedia pada tanggal tersebut.`);
      return;
    }
  
    const totalPrice = calculateTotalPrice(newEvent.roomType, newEvent.checkin, newEvent.checkout);
  
    axios.post('http://localhost:8002/api/reservations', {
      first_name: newEvent.firstName,
      last_name: newEvent.lastName,
      email: newEvent.email,
      room_type: newEvent.roomType,
      sub_room: newEvent.subRoom,
      rate_plan: newEvent.ratePlan,
      adult: Number(newEvent.adult),
      children: Number(newEvent.children),
      check_in_date: newEvent.checkin,
      check_out_date: newEvent.checkout,
      total_price: totalPrice
    })
    .then((res) => {
      const newEventData = {
        id: res.data.id,
        title: `${res.data.first_name} ${res.data.last_name} - ${res.data.room_type} - ${res.data.sub_room}`,
        start: res.data.check_in_date,
        end: res.data.check_out_date,
        backgroundColor: '#3788d8',
        extendedProps: res.data
      };
  
      setEvents((prev) => [...prev, newEventData]);
      showSnackbar("Booking berhasil disimpan dan ditampilkan!");
  
      // ✅ Reset form setelah berhasil
      setNewEvent({
        open: false,
        firstName: '',
        lastName: '',
        email: '',
        roomType: '',
        subRoom: '',
        ratePlan: '',
        adult: '',
        children: '',
        checkin: '',
        checkout: '',
        totalPrice: 0,
      });
    })
    .catch(() => {
      showSnackbar("Gagal kirim ke backend ❌", "error");
    });
  };
  
  
  

  const handleAddMaintenance = () => {
    if (
      !maintenanceEvent.roomType ||
      !maintenanceEvent.room ||
      !maintenanceEvent.start ||
      !maintenanceEvent.end
    ) {
      showSnackbar("Mohon isi semua field yang diperlukan untuk maintenance.");
      return;
    }
  
    // Validasi ketersediaan kamar (tambahkan validasi di sini!)
    const available = checkRoomAvailability(
      maintenanceEvent.room,
      maintenanceEvent.start,
      maintenanceEvent.end
    );
  
    if (!available) {
      showSnackbar(`Kamar nomor ${maintenanceEvent.room} sudah digunakan pada tanggal tersebut.`);
      return;
    }
  
    const id = `maintenance-${Date.now()}`;
    const title = `Maintenance - Room ${maintenanceEvent.room}`;
    setEvents((prevEvents) => [
      ...prevEvents,
      {
        id,
        title,
        start: maintenanceEvent.start,
        end: maintenanceEvent.end,
        backgroundColor: 'black',
        extendedProps: {
          isMaintenance: true,
          reason: maintenanceEvent.reason,
          roomType: maintenanceEvent.roomType,
          subRoom: maintenanceEvent.room,
        },
      },
    ]);
  
    setMaintenanceModal(false);
    setMaintenanceEvent({ roomType: '', room: '', reason: '', start: '', end: '' });
  
    showSnackbar("Maintenance berhasil ditambahkan!");
  };
  

  const calculateTotalPrice = (roomType, checkin, checkout) => {
    const roomPrices = {
      Standard: 500000,
      Superrior: 750000,
    };
  
    if (!roomType || !checkin || !checkout) return 0;
  
    const checkinDate = new Date(checkin);
    const checkoutDate = new Date(checkout);
    const nightCount = Math.ceil((checkoutDate - checkinDate) / (1000 * 60 * 60 * 24));
  
    return nightCount > 0 ? nightCount * (roomPrices[roomType] || 0) : 0;
  };
  
// Konfirmasi Schedule
  const [rescheduleInfo, setRescheduleInfo] = useState({
    open: false,
    event: null,
    newStart: '',
    newEnd: '',
    revert: () => {} // Fungsi untuk cancel
  });

  const handleEventClick = (info) => {
    info.jsEvent.preventDefault();
  
    if (info.event.extendedProps?.isMaintenance) {
      setSelectedEvent({
        id: info.event.id, // 🚩 tambahkan ini
        title: info.event.title,
        start: info.event.startStr,
        end: info.event.endStr,
        reason: info.event.extendedProps.reason,
        isMaintenance: true,
        subRoom: info.event.extendedProps.subRoom,
        roomType: info.event.extendedProps.roomType,
      });
    } else {
      setSelectedEvent({
        ...info.event.extendedProps,
        id: info.event.id,
        title: info.event.title,
        start: info.event.startStr,
        end: info.event.endStr,
        backgroundColor: info.event.backgroundColor
      });
    }
    setEditMode(false);
  };

  // Add this state at the top of your component
const [currentTime, setCurrentTime] = useState(new Date());

// Add this useEffect for the live clock
useEffect(() => {
  const timer = setInterval(() => {
    setCurrentTime(new Date());
  }, 1000);
  
  return () => clearInterval(timer);
}, []);

const [roomStatus, setRoomStatus] = useState({
  available: rooms.length,
  booked: 0,
  maintenance: 0
});

const [monthlyOccupancy, setMonthlyOccupancy] = useState(0);

useEffect(() => {
  // Calculate room status
  const bookedRooms = events.filter(event => 
    !event.extendedProps?.isMaintenance && 
    new Date(event.end) >= new Date()
  ).length;

  const maintenanceRooms = events.filter(event => 
    event.extendedProps?.isMaintenance && 
    new Date(event.end) >= new Date()
  ).length;

  setRoomStatus({
    available: rooms.length - bookedRooms - maintenanceRooms,
    booked: bookedRooms,
    maintenance: maintenanceRooms
  });

  // Calculate monthly occupancy percentage
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  
  const monthlyBookings = events.filter(event => {
    const eventDate = new Date(event.start);
    return (
      eventDate.getMonth() === currentMonth &&
      eventDate.getFullYear() === currentYear &&
      !event.extendedProps?.isMaintenance
    );
  }).length;

  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const totalPossibleBookings = rooms.length * daysInMonth;
  const occupancyPercentage = totalPossibleBookings > 0 
    ? Math.round((monthlyBookings / totalPossibleBookings) * 100)
    : 0;

  setMonthlyOccupancy(occupancyPercentage);
}, [events, rooms.length]);
  

  const handleEventDrop = (info) => {
    if (lockDrag) {
      info.revert(); // kembalikan ke posisi semula
      showSnackbar('Fitur drag sedang dikunci.', 'warning');
      return;
    }
  
    // Lanjutkan ke logic yang sudah ada sebelumnya
    setRescheduleInfo({
      open: true,
      event: info.event,
      newStart: info.event.startStr,
      newEnd: info.event.endStr,
      revert: info.revert
    });
  };
  
  const handleEventResize = (info) => {
    if (lockDrag) {
      info.revert();
      showSnackbar('Fitur resize sedang dikunci.', 'warning');
      return;
    }
  
    setRescheduleInfo({
      open: true,
      event: info.event,
      newStart: info.event.startStr,
      newEnd: info.event.endStr,
      revert: info.revert
    });
  };
  
  
  const confirmReschedule = () => {
    const { event, newStart, newEnd } = rescheduleInfo;
  
    // 🚩 Kirim event.id sebagai parameter terakhir untuk diabaikan
    const available = checkRoomAvailability(
      event.extendedProps.subRoom,
      newStart,
      newEnd,
      event.id
    );
  
    if (!available) {
      showSnackbar(`Kamar nomor ${event.extendedProps.subRoom} tidak tersedia pada tanggal tersebut.`);
      rescheduleInfo.revert(); // Kembali ke posisi awal
      setRescheduleInfo({ ...rescheduleInfo, open: false });
      return;
    }
  
    // Jika tersedia, lakukan update
    setEvents((prevEvents) => {
      return prevEvents.map((ev) => {
        if (ev.id === event.id) {
          const newPrice = calculateTotalPrice(ev.extendedProps.roomType, newStart, newEnd);
          return {
            ...ev,
            start: newStart,
            end: newEnd,
            extendedProps: {
              ...ev.extendedProps,
              checkin: newStart,
              checkout: newEnd,
              totalPrice: newPrice,
            },
          };
        }
        return ev;
      });
    });
  
    setRescheduleInfo({ ...rescheduleInfo, open: false });
    showSnackbar('Reschedule berhasil!');
  };
  
  

 
  return (
    <>
    <Box  sx={{ mb: 4 }}>
  {/* First Row - Title and Live Clock */}
  <Box sx={{ 
    display: 'flex', 
    justifyContent: 'space-between', 
    alignItems: 'center',
    mb: 2
  }}>
    <Typography variant="h5" sx={{ fontWeight: 600 }}>
      Booking Chart
    </Typography>
    
    <Box sx={{ 
      display: 'flex',
      alignItems: 'center',
      backgroundColor: '#f5f5f5',
      p: 1,
      borderRadius: 1
    }}>
      <Typography variant="subtitle1" sx={{ fontWeight: 500 }}>
        {currentTime.toLocaleDateString('id-ID', {
          weekday: 'long',
          day: 'numeric',
          month: 'long',
          year: 'numeric'
        })}
      </Typography>
      <Typography variant="subtitle1" sx={{ fontWeight: 500, ml: 2 }}>
        {currentTime.toLocaleTimeString('id-ID')}
      </Typography>
    </Box>
  </Box>




  {/* Second Row - Room Status */}
  <Box
  sx={{
    display: 'flex',
    justifyContent: 'space-between',
    gap: 2,
    mb: 4,
    flexWrap: 'wrap' // agar responsif
  }}
>
  <MainCard
    sx={{ p: 2, flex: 1, bgcolor: 'secondary.A100' }}
    content={false}
  >
    <Box display="flex" alignItems="center" gap={2}>
      <Box
        sx={{
          bgcolor: 'success.main',
          color: 'white',
          p: 1,
          borderRadius: 2,
          display: 'flex',
          alignItems: 'center'
        }}
      >
        <HotelIcon fontSize="small" />
      </Box>
      <Box>
        <Typography variant="subtitle2" color="textSecondary">
          Rooms Available
        </Typography>
        <Typography variant="h4" sx={{ fontWeight: 700 }}>
          {roomStatus.available}
        </Typography>
      </Box>
    </Box>
  </MainCard>

  <MainCard
    sx={{ p: 2, flex: 1, bgcolor: 'secondary.A100' }}
    content={false}
  >
    <Box display="flex" alignItems="center" gap={2}>
      <Box
        sx={{
          bgcolor: 'warning.main',
          color: 'white',
          p: 1,
          borderRadius: 2,
          display: 'flex',
          alignItems: 'center'
        }}
      >
        <BedIcon fontSize="small" />
      </Box>
      <Box>
        <Typography variant="subtitle2" color="textSecondary">
          Rooms Booked
        </Typography>
        <Typography variant="h4" sx={{ fontWeight: 700 }}>
          {roomStatus.booked}
        </Typography>
      </Box>
    </Box>
  </MainCard>

  <MainCard
    sx={{ p: 2, flex: 1, bgcolor: 'secondary.A100' }}
    content={false}
  >
    <Box display="flex" alignItems="center" gap={2}>
      <Box
        sx={{
          bgcolor: 'error.main',
          color: 'white',
          p: 1,
          borderRadius: 2,
          display: 'flex',
          alignItems: 'center'
        }}
      >
        <BuildIcon fontSize="small" />
      </Box>
      <Box>
        <Typography variant="subtitle2" color="textSecondary">
          In Maintenance
        </Typography>
        <Typography variant="h4" sx={{ fontWeight: 700 }}>
          {roomStatus.maintenance}
        </Typography>
      </Box>
    </Box>
  </MainCard>

  <MainCard
    sx={{ p: 2, flex: 1, bgcolor: 'secondary.A100' }}
    content={false}
  >
    <Box display="flex" alignItems="center" gap={2}>
      <Box
        sx={{
          bgcolor: 'primary.main',
          color: 'white',
          p: 1,
          borderRadius: 2,
          display: 'flex',
          alignItems: 'center'
        }}
      >
        <CalendarMonthIcon fontSize="small" />
      </Box>
      <Box>
        <Typography variant="subtitle2" color="textSecondary">
          Monthly Occupancy
        </Typography>
        <Typography variant="h4" sx={{ fontWeight: 700 }}>
          {monthlyOccupancy}%
        </Typography>
      </Box>
    </Box>
  </MainCard>
</Box>

  {/* Third Row - Controls */}
  <Box
  sx={{
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 2,
    mb: 2
  }}
>
  {/* Kiri: Filter Tanggal + Navigasi Kalender */}
  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
    <TextField
      label="Filter Tanggal"
      type="date"
      value={filterDate}
      onChange={(e) => {
        setFilterDate(e.target.value);
        if (calendarRef.current) {
          calendarRef.current.getApi().gotoDate(e.target.value);
        }
      }}
      InputLabelProps={{ shrink: true }}
      sx={{ width: 200 }}
      size="small"
    />

    <Stack direction="row" spacing={1}>
    <Button
  sx={{ 
    backgroundColor: (theme) => theme.palette.primary.light,
    color: 'white',
    boxShadow: theme => theme.shadows[1],
    '&:hover': {
      backgroundColor: (theme) => theme.palette.primary.main,
      color: 'white'
    }
  }}
  onClick={() => calendarRef.current.getApi().prev()}
>
  ❮
</Button>

<Button 
  onClick={() => calendarRef.current.getApi().next()}
  sx={{ 
    backgroundColor: (theme) => theme.palette.primary.light,
    color: 'white',
    boxShadow: theme => theme.shadows[1],
    '&:hover': {
      backgroundColor: (theme) => theme.palette.primary.main,
      color: 'white'
    }
  }}
>
  ❯
</Button>

<Button
  variant="outlined"
  color="primary"
  onClick={() => calendarRef.current.getApi().today()}
>
  Today
</Button>

    </Stack>
  </Box>

  {/* Kanan: Tombol Aksi */}
  <Stack direction="row" spacing={2}>
    <Button
      variant="contained"
      startIcon={<AddIcon />}
      color="primary"
      onClick={() =>
        setNewEvent({
          open: true,
          firstName: '',
          lastName: '',
          email: '',
          roomType: '',
          subRoom: '',
          ratePlan: '',
          adult: '',
          children: '',
          checkin: '',
          checkout: '',
          totalPrice: 0,
        })
      }
    >
      Add Reservasi
    </Button>

    <Button
      variant="contained"
      color={lockDrag ? 'secondary' : 'success'}
      startIcon={lockDrag ? <LockIcon /> : <LockOpenIcon />}
      onClick={() => setLockDrag(!lockDrag)}
    >
      {lockDrag ? 'Unlock Drag' : 'Lock Drag'}
    </Button>

    <Button
      variant="contained"
      startIcon={<BuildIcon />}
      color="warning"
      onClick={() => setMaintenanceModal(true)}
    >
      Room Maintenance
    </Button>
  </Stack>
</Box>

</Box >


<FullCalendar
        ref={calendarRef}
        plugins={[dayGridPlugin, interactionPlugin]}
        initialView="dayGridMonth"
        eventDrop={handleEventDrop} // Untuk update tanggal otomatis
        editable={!lockDrag} 
        selectable={true}
        events={events}
        dateClick={handleDateClick}
        eventClick={handleEventClick}
        eventResize={handleEventResize} 
        headerToolbar={false}
        eventDisplay="block"
        eventTimeFormat={{
          hour: '2-digit',
          minute: '2-digit',
          meridiem: false
        }}
      />
      

{/* Reschedule Confirmation Modal */}
<Dialog open={rescheduleInfo.open} onClose={() => setRescheduleInfo({...rescheduleInfo, open: false})}>
  <DialogTitle>Konfirmasi Reschedule</DialogTitle>
  <DialogContent>
    <Typography gutterBottom>
      Anda yakin ingin memindahkan booking ini?
    </Typography>
    <Box sx={{ mt: 2 }}>
      <Typography>
        <strong>Tanggal Lama:</strong> {new Date(rescheduleInfo.event?.startStr).toLocaleDateString()}
      </Typography>
      <Typography>
        <strong>Tanggal Baru:</strong> {new Date(rescheduleInfo.newStart).toLocaleDateString()}
      </Typography>
    </Box>
  </DialogContent>
  <DialogActions>
    <Button 
      onClick={() => {
        rescheduleInfo.revert();
        setRescheduleInfo({...rescheduleInfo, open: false});
      }}
    >
      Batal
    </Button>
    <Button 
      variant="contained" 
      onClick={confirmReschedule}
      color="primary"
    >
      Konfirmasi
    </Button>
  </DialogActions>
</Dialog>
  


      {/* Modal Tambah Reservasi */}
      <Modal open={newEvent.open} onClose={() => setNewEvent({ ...newEvent, open: false })}>
        <Box sx={{ p: 3, bgcolor: 'white', borderRadius: 2, maxWidth: 600, mx: 'auto', mt: 10 }}>
          <Typography variant="h6">Tambah Booking</Typography>
          <Grid container spacing={2}>
            <Grid item xs={6}>
              <TextField 
                label="First Name" 
                fullWidth 
                value={newEvent.firstName} 
                onChange={(e) => setNewEvent({ ...newEvent, firstName: e.target.value })} 
              />
            </Grid>
            <Grid item xs={6}>
              <TextField 
                label="Last Name" 
                fullWidth 
                value={newEvent.lastName} 
                onChange={(e) => setNewEvent({ ...newEvent, lastName: e.target.value })} 
              />
            </Grid>
            <Grid item xs={6}>
              <TextField 
                label="Email" 
                fullWidth 
                value={newEvent.email} 
                onChange={(e) => setNewEvent({ ...newEvent, email: e.target.value })} 
              />
            </Grid>
            <Grid item xs={6}>
  <TextField
    label="Rooms"
    select
    fullWidth
    value={newEvent.roomType}
    onChange={(e) => {
      const updatedRoomType = e.target.value;
      setNewEvent((prev) => ({
        ...prev,
        roomType: updatedRoomType,
        subRoom: '', // Reset subroom ketika tipe kamar berubah
        totalPrice: calculateTotalPrice(updatedRoomType, prev.checkin, prev.checkout),
      }));
    }}
  >
    <MenuItem value="Standard">Standard</MenuItem>
    <MenuItem value="Superior">Superior</MenuItem>
  </TextField>
</Grid>
<Grid item xs={6}>
<TextField
  label="Nomor Kamar"
  select
  fullWidth
  value={newEvent.subRoom}
  onChange={(e) => setNewEvent({ ...newEvent, subRoom: e.target.value })}
  disabled={!newEvent.roomType}
>
  <MenuItem value="" disabled>
    Pilih Nomor Kamar
  </MenuItem>
  {rooms
  .filter((room) => room.roomType === newEvent.roomType)
  .map((room) => {
    const isUnavailable = !checkRoomAvailability(room.subRoom, newEvent.checkin, newEvent.checkout);
    return (
      <MenuItem
        key={room.subRoom}
        value={room.subRoom}
        disabled={isUnavailable}
      >
        {room.subRoom} {isUnavailable ? '(Dipakai)' : ''}
      </MenuItem>
    );
  })}
</TextField>



</Grid>

            <Grid item xs={6}>
              <TextField 
                label="Rate Plan" 
                select 
                fullWidth 
                value={newEvent.ratePlan} 
                onChange={(e) => setNewEvent({ ...newEvent, ratePlan: e.target.value })}
              >
                <MenuItem value="Rooms Only">Rooms Only</MenuItem>
                <MenuItem value="Breakfast Included">Breakfast Included</MenuItem>
              </TextField>
            </Grid>
            <Grid item xs={3}>
              <TextField 
                label="Adult" 
                type="number" 
                fullWidth 
                value={newEvent.adult} 
                onChange={(e) => setNewEvent({ ...newEvent, adult: e.target.value })} 
              />
            </Grid>
            <Grid item xs={3}>
              <TextField 
                label="Children" 
                type="number" 
                fullWidth 
                value={newEvent.children} 
                onChange={(e) => setNewEvent({ ...newEvent, children: e.target.value })} 
              />
            </Grid>
            <Grid item xs={6}>
              <TextField 
                label="Check-in" 
                type="date" 
                fullWidth 
                InputLabelProps={{ shrink: true }} 
                value={newEvent.checkin} 
                onChange={(e) => {
                  const updatedCheckin = e.target.value;
                  setNewEvent(prev => {
                    const newTotalPrice = calculateTotalPrice(prev.roomType, updatedCheckin, prev.checkout);
                    return {
                      ...prev,
                      checkin: updatedCheckin,
                      totalPrice: newTotalPrice,
                    };
                  });
                }}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField 
                label="Check-out" 
                type="date" 
                fullWidth 
                InputLabelProps={{ shrink: true }} 
                value={newEvent.checkout} 
                onChange={(e) => {
                  const updatedCheckout = e.target.value;
                  setNewEvent(prev => {
                    const newTotalPrice = calculateTotalPrice(prev.roomType, prev.checkin, updatedCheckout);
                    return {
                      ...prev,
                      checkout: updatedCheckout,
                      totalPrice: newTotalPrice,
                    };
                  });
                }}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField 
                label="Total Accommodation (IDR)" 
                fullWidth 
                value={(newEvent.totalPrice || 0).toLocaleString('id-ID', {
                  style: 'currency',
                  currency: 'IDR'
                })} 
                InputProps={{ readOnly: true }}
              />
            </Grid>
          </Grid>
          <Box mt={2} textAlign="right">
            <Button onClick={handleAddEvent} variant="contained">Simpan Booking</Button>
          </Box>
        </Box>
      </Modal>

{/* Modal update Reservasi */}
<Modal open={!!selectedEvent} onClose={() => {
  setSelectedEvent(null);
  setEditMode(false);
}}>
  <Box sx={{ 
    p: 3, 
    bgcolor: 'white', 
    borderRadius: 2, 
    maxWidth: 600, 
    mx: 'auto', 
    mt: 10,
    maxHeight: '80vh',
    overflowY: 'auto'
  }}>
    <Box display="flex" justifyContent="space-between" alignItems="center">
      <Typography variant="h6" gutterBottom>
        {editMode ? 'Edit Reservasi' : 'Detail Reservasi'} - {selectedEvent?.roomType} Room
      </Typography>
      <IconButton onClick={() => setSelectedEvent(null)}>
        <CloseIcon />
      </IconButton>
    </Box>

    {selectedEvent && !selectedEvent.isMaintenance && (
      <Grid container spacing={2} sx={{ mt: 1 }}>
        <Grid item xs={6}>
          <TextField
            label="Nama Depan"
            value={selectedEvent.firstName || '-'}
            fullWidth
            InputProps={{ readOnly: !editMode }}
            onChange={(e) => setSelectedEvent({...selectedEvent, firstName: e.target.value})}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            label="Nama Belakang"
            value={selectedEvent.lastName || '-'}
            fullWidth
            InputProps={{ readOnly: !editMode }}
            onChange={(e) => setSelectedEvent({...selectedEvent, lastName: e.target.value})}
          />
        </Grid>
        <Grid item xs={12}>
          <TextField
            label="Email"
            value={selectedEvent.email || '-'}
            fullWidth
            InputProps={{ readOnly: !editMode }}
            onChange={(e) => setSelectedEvent({...selectedEvent, email: e.target.value})}
          />
        </Grid>
        <Grid item xs={6}>
        <TextField
  label="Tipe Kamar"
  select
  fullWidth
  value={selectedEvent?.roomType || ''}
  InputProps={{ readOnly: !editMode }}
  onChange={(e) => {
    const updatedRoomType = e.target.value;
    setSelectedEvent((prev) => ({
      ...prev,
      roomType: updatedRoomType,
      subRoom: '', // Reset subRoom saat roomType diganti
      totalPrice: calculateTotalPrice(updatedRoomType, prev.checkin, prev.checkout)
    }));
  }}
>
  <MenuItem value="Standard">Standard</MenuItem>
  <MenuItem value="Superior">Superior</MenuItem>
</TextField>

        </Grid> 
        <Grid item xs={6}>
        <TextField
  label="Nomor Kamar"
  select
  fullWidth
  value={selectedEvent?.subRoom || ''}
  onChange={(e) => setSelectedEvent({ ...selectedEvent, subRoom: e.target.value })}
  disabled={!editMode || !selectedEvent?.roomType}
>
  <MenuItem value="" disabled>
    Pilih Nomor Kamar
  </MenuItem>
  {rooms
  .filter((room) => room.roomType === selectedEvent?.roomType)
  .map((room) => {
    const isUnavailable = !checkRoomAvailability(
      room.subRoom,
      selectedEvent?.checkin,
      selectedEvent?.checkout,
      selectedEvent?.id // abaikan event ini sendiri saat validasi
    );
    return (
      <MenuItem
        key={room.subRoom}
        value={room.subRoom}
        disabled={isUnavailable}
      >
        {room.subRoom} {isUnavailable ? '(Dipakai)' : ''}
      </MenuItem>
    );
  })}

</TextField>

        </Grid>
        <Grid item xs={6}>
  <TextField
    label="Rate Plan"
    select // 🚀 Ubah menjadi select dropdown
    value={selectedEvent.ratePlan || ''}
    fullWidth
    InputProps={{ readOnly: !editMode }}
    onChange={(e) => setSelectedEvent({...selectedEvent, ratePlan: e.target.value})}
  >
    <MenuItem value="Rooms Only">Rooms Only</MenuItem>
    <MenuItem value="Breakfast Included">Breakfast Included</MenuItem>
  </TextField>
</Grid>
        <Grid item xs={3}>
          <TextField
            label="Dewasa"
            value={selectedEvent.adult || '-'}
            fullWidth
            InputProps={{ readOnly: !editMode }}
            onChange={(e) => setSelectedEvent({...selectedEvent, adult: e.target.value})}
          />
        </Grid>
        <Grid item xs={3}>
          <TextField
            label="Anak-anak"
            value={selectedEvent.children || '-'}
            fullWidth
            InputProps={{ readOnly: !editMode }}
            onChange={(e) => setSelectedEvent({...selectedEvent, children: e.target.value})}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            label="Check-in"
            value={selectedEvent.checkin || '-'}
            fullWidth
            InputProps={{ readOnly: true }}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            label="Check-out"
            value={selectedEvent.checkout || '-'}
            fullWidth
            InputProps={{ readOnly: true }}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            label="Total Harga"
            value={(selectedEvent.totalPrice || 0).toLocaleString('id-ID', {
              style: 'currency',
              currency: 'IDR'
            })}
            fullWidth
            InputProps={{ readOnly: true }}
          />
        </Grid>
      </Grid>
    )}

<Box mt={3} display="flex" justifyContent="space-between">
  {/* Tombol Hapus */}
  <Button 
    variant="contained" 
    color="error"
    startIcon={<DeleteIcon />}
    onClick={() => setDeleteConfirm(true)}
    sx={{ mr: 1 }}
  >
    Hapus
  </Button>
  
  {editMode ? ( // 🚀 PERUBAHAN: Kondisional tombol edit/simpan
    <>
      <Button 
        variant="outlined"
        onClick={() => setEditMode(false)} // 🚀 PERUBAHAN: Batal edit
        sx={{ mr: 1 }}
      >
        Batal
      </Button>
      <Button 
        variant="contained" 
        color="success"
        startIcon={<SaveIcon />}
        onClick={handleUpdateEvent} // 🚀 PERUBAHAN: Simpan perubahan
      >
        Simpan
      </Button>
    </>
  ) : (
    <Button 
      variant="contained" 
      startIcon={<EditIcon />}
      onClick={() => setEditMode(true)} // 🚀 PERUBAHAN: Aktifkan edit mode
    >
      Edit
    </Button>
  )}
</Box>
  </Box>
</Modal>

{/* Modal Konfirmasi Hapus */}
<Dialog open={deleteConfirm} onClose={() => setDeleteConfirm(false)}>
  <DialogTitle>Konfirmasi Hapus Event</DialogTitle>
  <DialogContent>
    <Typography>
      Apakah Anda yakin ingin menghapus {selectedEvent?.isMaintenance ? 'Maintenance' : 'Reservasi'} ini?
    </Typography>
  </DialogContent>
  <DialogActions>
    <Button onClick={() => setDeleteConfirm(false)}>Batal</Button>
    <Button 
      color="error"
      variant="contained"
      onClick={handleDeleteEvent}
    >
      Hapus
    </Button>
  </DialogActions>
</Dialog>



      {/* Modal Tambah Maintenance */}
      <Modal open={maintenanceModal} onClose={() => setMaintenanceModal(false)}>
  <Box sx={{ p: 3, bgcolor: 'white', borderRadius: 2, maxWidth: 600, mx: 'auto', mt: 10 }}>
    <Typography variant="h6">Tambah Room Maintenance</Typography>
    <Stack spacing={2}>
      {/* Pilih Tipe Kamar */}
      <TextField
        label="Tipe Kamar"
        select
        fullWidth
        value={maintenanceEvent.roomType}
        onChange={(e) =>
          setMaintenanceEvent({ ...maintenanceEvent, roomType: e.target.value, room: '' })
        }
      >
        <MenuItem value="Standard">Standard</MenuItem>
        <MenuItem value="Superior">Superior</MenuItem>
      </TextField>

      {/* Pilih Nomor Kamar Dinamis */}
      <TextField
        label="Nomor Kamar"
        select
        fullWidth
        disabled={!maintenanceEvent.roomType}
        value={maintenanceEvent.room}
        onChange={(e) => setMaintenanceEvent({ ...maintenanceEvent, room: e.target.value })}
      >
        {rooms
          .filter((room) => room.roomType === maintenanceEvent.roomType)
          .map((room) => (
            <MenuItem key={room.subRoom} value={room.subRoom}>
              {room.subRoom}
            </MenuItem>
          ))}
      </TextField>

      {/* Alasan */}
      <TextField
        label="Alasan"
        fullWidth
        multiline
        rows={2}
        value={maintenanceEvent.reason}
        onChange={(e) => setMaintenanceEvent({ ...maintenanceEvent, reason: e.target.value })}
      />

      {/* Mulai */}
      <TextField
        label="Mulai"
        type="date"
        fullWidth
        InputLabelProps={{ shrink: true }}
        value={maintenanceEvent.start}
        onChange={(e) => setMaintenanceEvent({ ...maintenanceEvent, start: e.target.value })}
      />

      {/* Selesai */}
      <TextField
        label="Selesai"
        type="date"
        fullWidth
        InputLabelProps={{ shrink: true }}
        value={maintenanceEvent.end}
        onChange={(e) => setMaintenanceEvent({ ...maintenanceEvent, end: e.target.value })}
      />

      <Button onClick={handleAddMaintenance} variant="contained">
        Simpan Maintenance
      </Button>
    </Stack>
  </Box>
</Modal>

<Snackbar
  open={snackbar.open}
  autoHideDuration={4000}
  onClose={handleCloseSnackbar}
  anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
>
  <Alert severity={snackbar.severity} variant="filled" onClose={handleCloseSnackbar}>
    {snackbar.message}
  </Alert>
</Snackbar>



    </>
  );
}